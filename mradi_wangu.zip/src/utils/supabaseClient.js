import { createClient } from '@supabase/supabase-js';

// Anwani ya Seva yako ya Supabase kulingana na ID ya mradi wako
const supabaseUrl = "https://idnpricbfgiwzifwlwii.supabase.co";

// Ufunguo wako wa kipekee wa usalama (Anon Public Key)
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlkbnByaWNiZmdpd3ppZndsd2lpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY4NjU0MDgsImV4cCI6MjA5MjQ0MTQwOH0.FItNI4jDuwShdpJGAOXnebMFO7Wd5RqsJp7gP7ZhMy4";

// Kutengeneza mtambo mkuu wa mawasiliano (Supabase Client Instance)
export const supabase = createClient(supabaseUrl, supabaseAnonKey);

