import React, { useState, useEffect } from 'react';
import html2pdf from 'html2pdf.js';

export default function Checkout({ cartItems, onUpdateQuantity, onClearCart }) {
  const [step, setStep] = useState(1); // 1: Cart, 2: Payment, 3: Success
  const [customerInfo, setCustomerInfo] = useState({ name: '', phone: '', paymentMethod: 'M-Pesa' });
  const [isVerifying, setIsVerifying] = useState(false);
  const [verifyProgress, setVerifyProgress] = useState(0);

  // Hesabu ya Jumla ya Bei ya huduma zilizochaguliwa
  const totalPrice = cartItems.reduce((sum, item) => sum + (item.price * (item.quantity || 1)), 0);

  // Kisimulizi cha Uhakiki wa Malipo Kiotomatiki
  useEffect(() => {
    let interval;
    if (isVerifying) {
      interval = setInterval(() => {
        setVerifyProgress((oldProgress) => {
          if (oldProgress >= 100) {
            clearInterval(interval);
            setTimeout(() => {
              setIsVerifying(false);
              setStep(3); // Badilisha kwenda hatua ya mwisho ya Mafanikio
              triggerAutomaticActions(); // Washa amri za kiotomatiki
            }, 1000);
            return 1000;
          }
          return oldProgress + 25; // Huongezeka kwa 25% kila sekunde
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isVerifying]);

  const handleStartPayment = (e) => {
    e.preventDefault();
    if (!customerInfo.name || !customerInfo.phone) {
      alert('Tafadhali jaza Jina na Namba ya Simu ili kuendelea!');
      return;
    }
    setStep(2); // Nenda kwenye ukurasa wa Malipo
  };

  const handleVerifyPayment = () => {
    setIsVerifying(true);
    setVerifyProgress(0);
  };

  // Kazi za Kiotomatiki Baada ya Malipo Kuhakikiwa Kikamilifu
  const triggerAutomaticActions = () => {
    // 1. Kupakua PDF ya Hali ya Juu Pekee
    generateAndDownloadPDF(); 
    
    // 2. Kufungua WhatsApp baada ya sekunde 2 ili kuruhusu PDF ikamilike
    setTimeout(() => {
      sendWhatsAppOrder();
      onClearCart(); // Safisha kikapu baada ya kukamilisha kila kitu
    }, 2000);
  };

  // AMRI YA KUTENGENEZA NA KUPAKUA EXECUTIVE INVOICE YA PDF
  const generateAndDownloadPDF = () => {
    const invoiceId = `LSIC-${Math.floor(100000 + Math.random() * 900000)}`;
    const date = new Date().toLocaleDateString('sw-TZ');

    // Muundo wa HTML wa kifahari wa PDF yenye nembo na rangi za Letema Group
    const element = document.createElement('div');
    element.innerHTML = `
      <div style="padding: 30px; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; color: #333; background-color: #ffffff; max-width: 800px; margin: auto;">
        
        <table style="width: 100%; border-bottom: 2px solid #1e3a8a; padding-bottom: 20px;">
          <tr>
            <td style="vertical-align: top;">
              <h1 style="margin: 0; color: #1e3a8a; font-size: 24px; text-transform: uppercase; letter-spacing: -0.5px;">LETEMA GROUP</h1>
              <p style="margin: 2px 0; font-size: 11px; color: #6b7280; font-weight: bold; text-transform: uppercase; letter-spacing: 2px;">LSIC Business Hub & Innovation Center</p>
              <p style="margin: 15px 0 0 0; font-size: 11px; color: #4b5563; line-height: 1.5;">
                Mbeya Business & Digital Hub<br>
                Email: letemaalexander3002@gmail.com<br>
                Simu: +255 620 642 652
              </p>
            </td>
            <td style="text-align: right; vertical-align: top;">
              <div style="background-color: #f3f4f6; padding: 12px; border-radius: 8px; border: 1px solid #e5e7eb; display: inline-block; text-align: left;">
                <h3 style="margin: 0 0 5px 0; font-size: 12px; color: #1f2937; text-transform: uppercase; tracking-wider: 1px;">STAKABADHI RASMI (INVOICE)</h3>
                <p style="margin: 2px 0; font-size: 11px;"><b>Namba:</b> ${invoiceId}</p>
                <p style="margin: 2px 0; font-size: 11px;"><b>Tarehe:</b> ${date}</p>
                <p style="margin: 2px 0; font-size: 11px;"><b>Hali:</b> <span style="color: #047857; font-weight: bold;">IMEHAKIKISHWA (PAID)</span></p>
              </div>
            </td>
          </tr>
        </table>

        <div style="margin-top: 25px; margin-bottom: 25px;">
          <h4 style="margin: 0 0 8px 0; font-size: 12px; color: #1e3a8a; text-transform: uppercase;">Imetolewa Kwa:</h4>
          <p style="margin: 2px 0; font-size: 12px;"><b>👤 Jina la Mteja:</b> ${customerInfo.name}</p>
          <p style="margin: 2px 0; font-size: 12px;"><b>📞 Namba ya Simu:</b> ${customerInfo.phone}</p>
          <p style="margin: 2px 0; font-size: 12px;"><b>💳 Njia ya Malipo:</b> ${customerInfo.paymentMethod}</p>
        </div>

        <table style="width: 100%; border-collapse: collapse; margin-top: 15px;">
          <thead>
            <tr style="background-color: #1e3a8a; color: #ffffff; text-align: left;">
              <th style="padding: 10px; font-size: 11px; text-transform: uppercase; border: 1px solid #1e3a8a;">Maelezo ya Huduma / Bidhaa</th>
              <th style="padding: 10px; font-size: 11px; text-transform: uppercase; border: 1px solid #1e3a8a; text-align: center; width: 80px;">Idadi</th>
              <th style="padding: 10px; font-size: 11px; text-transform: uppercase; border: 1px solid #1e3a8a; text-align: right; width: 120px;">Bei ya Kipengele</th>
              <th style="padding: 10px; font-size: 11px; text-transform: uppercase; border: 1px solid #1e3a8a; text-align: right; width: 120px;">Jumla ndogo</th>
            </tr>
          </thead>
          <tbody>
            ${cartItems.map((item, idx) => `
              <tr style="background-color: ${idx % 2 === 0 ? '#ffffff' : '#f9fafb'};">
                <td style="padding: 10px; font-size: 11px; border: 1px solid #e5e7eb; font-weight: bold; color: #1f2937;">${item.name}</td>
                <td style="padding: 10px; font-size: 11px; border: 1px solid #e5e7eb; text-align: center; color: #4b5563;">${item.quantity || 1}</td>
                <td style="padding: 10px; font-size: 11px; border: 1px solid #e5e7eb; text-align: right; color: #4b5563;">${item.price.toLocaleString()} TZS</td>
                <td style="padding: 10px; font-size: 11px; border: 1px solid #e5e7eb; text-align: right; font-weight: bold; color: #1f2937;">${(item.price * (item.quantity || 1)).toLocaleString()} TZS</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <table style="width: 100%; margin-top: 20px;">
          <tr>
            <td style="width: 50%;"></td>
            <td style="width: 50%;">
              <table style="width: 100%; border-collapse: collapse;">
                <tr style="border-top: 2px solid #1e3a8a;">
                  <td style="padding: 12px 10px; font-size: 13px; font-weight: bold; color: #1e3a8a; text-transform: uppercase;">JUMLA KUU V.A.T Inc:</td>
                  <td style="padding: 12px 10px; font-size: 14px; font-weight: bold; color: #1e3a8a; text-align: right;">${totalPrice.toLocaleString()} TZS</td>
                </tr>
              </table>
            </td>
          </tr>
        </table>

        <div style="margin-top: 60px; text-align: center; border-top: 1px dashed #d1d5db; padding-top: 20px;">
          <p style="margin: 0; font-size: 11px; font-style: italic; color: #4b5563; font-weight: bold;">
            "Huwezi kujenga ufalme wa kesho kwa akili ya jana."
          </p>
          <p style="margin: 8px 0 0 0; font-size: 10px; color: #9ca3af; font-weight: bold; text-transform: uppercase; letter-spacing: 1px;">
            Letema Group Systems © 2026 • Imesasishwa Kidijitali
          </p>
        </div>

      </div>
    `;

    // Mipangilio ya ubora wa PDF
    const options = {
      margin:       10,
      filename:     `Invoice_${invoiceId}.pdf`,
      image:        { type: 'jpeg', quality: 0.98 },
      html2canvas:  { scale: 2, useCORS: true },
      jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    html2pdf().from(element).set(options).save();
  };

  // AMRI YA KUTUMA ODA WHATSAPP
  const sendWhatsAppOrder = () => {
    const businessPhone = '255620642652'; 
    let itemsText = cartItems.map(item => 
      `• ${item.name} (x${item.quantity || 1}) -> ${(item.price * (item.quantity || 1)).toLocaleString()} TZS`
    ).join('\n');

    const message = encodeURIComponent(
`🏛️ *LSIC NEW ORDER SYSTEM* 🏛️
-----------------------------------------
*TAARIFA ZA MTEJA:*
👤 *Jina:* ${customerInfo.name}
📞 *Simu:* ${customerInfo.phone}
💳 *Njia ya Malipo:* ${customerInfo.paymentMethod}
🟢 *Uhakiki wa Malipo:* Kikamilifu (Auto-Verified)

*HUDUMA / BIDHAA ZILIZOCHAGULIWA:*
${itemsText}

💰 *JUMLA KUU:* ${totalPrice.toLocaleString()} TZS
-----------------------------------------
_Oda hii imethibitishwa na stakabadhi rasmi ya Executive PDF imepakuliwa kwenye simu ya mteja._`
    );

    window.open(`https://wa.me/${businessPhone}?text=${message}`, '_blank');
  };

  if (cartItems.length === 0 && step !== 3) {
    return (
      <div className="max-w-md mx-auto text-center py-16 bg-white rounded-3xl border border-gray-150 p-6 shadow-sm">
        <p className="text-3xl">🛒</p>
        <p className="text-sm font-black text-gray-900 uppercase mt-4">Kikapu chako kipo wazi</p>
        <p className="text-xs text-gray-400 mt-1 font-medium">Nenda kwenye Katalogi kuongeza huduma za kidijitali.</p>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto p-4 space-y-6">
      
      {/* TIMELINE STEPS */}
      <div className="flex justify-between items-center bg-white border border-gray-100 p-4 rounded-2xl shadow-sm">
        {['1. Kikapu', '2. Malipo ya Uhakika', '3. Risiti ya PDF'].map((label, idx) => (
          <div key={idx} className="flex items-center space-x-2">
            <span className={`w-6 h-6 rounded-lg text-[10px] font-black flex items-center justify-center ${
              step === idx + 1 ? 'bg-blue-900 text-white shadow-md' : 'bg-gray-100 text-gray-400'
            }`}>{idx + 1}</span>
            <span className={`text-[11px] font-black hidden sm:inline ${step === idx + 1 ? 'text-blue-900' : 'text-gray-400'}`}>{label}</span>
          </div>
        ))}
      </div>

      {/* STEP 1: INTERACTIVE CART */}
      {step === 1 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-3">
            {cartItems.map(item => (
              <div key={item.id} className="bg-white border border-gray-150 p-4 rounded-2xl flex justify-between items-center shadow-sm">
                <div className="space-y-1 max-w-[65%]">
                  <h4 className="font-bold text-gray-900 text-xs line-clamp-1">{item.name}</h4>
                  <p className="text-xs font-black text-blue-900">{item.price.toLocaleString()} TZS</p>
                </div>
                <div className="flex items-center space-x-2 bg-gray-50 p-1.5 rounded-xl border">
                  <button onClick={() => onUpdateQuantity(item.id, (item.quantity || 1) - 1)} className="w-7 h-7 bg-white text-gray-800 font-black rounded-lg text-xs border active:scale-90">-</button>
                  <span className="text-xs font-black px-1 text-gray-900">{item.quantity || 1}</span>
                  <button onClick={() => onUpdateQuantity(item.id, (item.quantity || 1) + 1)} className="w-7 h-7 bg-white text-gray-800 font-black rounded-lg text-xs border active:scale-90">+</button>
                </div>
              </div>
            ))}
          </div>

          {/* TAARIFA ZA MTEJA FOMU */}
          <div className="bg-white p-5 rounded-2xl border border-gray-150 shadow-sm h-fit space-y-4">
            <h3 className="text-xs font-black text-gray-900 uppercase border-b pb-2">Thibitisha Agizo</h3>
            <form onSubmit={handleStartPayment} className="space-y-3">
              <div>
                <label className="block text-[10px] font-black uppercase text-gray-400 mb-1">Jina Kamili</label>
                <input type="text" required value={customerInfo.name} onChange={(e) => setCustomerInfo({...customerInfo, name: e.target.value})} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-blue-900" placeholder="Mteja wa LSIC" />
              </div>
              <div>
                <label className="block text-[10px] font-black uppercase text-gray-400 mb-1">Namba ya Simu</label>
                <input type="tel" required value={customerInfo.phone} onChange={(e) => setCustomerInfo({...customerInfo, phone: e.target.value})} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs font-black tracking-wider focus:outline-none focus:border-blue-900" placeholder="0620642652" />
              </div>
              <div className="pt-2 border-t flex justify-between items-center">
                <span className="text-[10px] font-black text-gray-400 uppercase">Jumla Kuu:</span>
                <span className="text-sm font-black text-blue-900">{totalPrice.toLocaleString()} TZS</span>
              </div>
              <button type="submit" className="w-full bg-blue-900 text-white text-xs font-black py-3 rounded-xl hover:bg-blue-950 uppercase transition-all tracking-wider shadow-md">Endelea Kwenye Malipo ➔</button>
            </form>
          </div>
        </div>
      )}

      {/* STEP 2: PAYMENT & AUTOMATIC VERIFICATION */}
      {step === 2 && (
        <div className="max-w-md mx-auto bg-white border border-gray-150 p-6 rounded-3xl shadow-lg space-y-6 text-center">
          <div>
            <h3 className="text-sm font-black text-gray-900 uppercase tracking-wider">Kituo cha Malipo ya Haraka</h3>
            <p className="text-xs text-gray-400 font-medium mt-1">Lipa kiasi kilichotajwa hapa chini ili mfumo uhakiki</p>
          </div>

          <div className="bg-blue-50/50 border border-blue-100 rounded-2xl py-4">
            <p className="text-[10px] font-black text-gray-400 uppercase">Kiasi cha Kulipia</p>
            <p className="text-xl font-black text-blue-900">{totalPrice.toLocaleString()} TZS</p>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {['M-Pesa', 'Tigo Pesa', 'Airtel Money'].map(method => (
              <button key={method} type="button" onClick={() => setCustomerInfo({...customerInfo, paymentMethod: method})} className={`py-2 px-1 text-[10px] font-black rounded-xl border transition-all ${customerInfo.paymentMethod === method ? 'bg-blue-900 text-white border-blue-900 shadow-md' : 'bg-white text-gray-600 hover:bg-gray-50'}`}>{method}</button>
            ))}
          </div>

          <div className="bg-gray-50 border p-4 rounded-xl text-left space-y-1.5 text-xs">
            <p className="font-bold text-gray-800">📌 Hatua za Kulipia:</p>
            <p className="text-gray-600 font-medium">1. Tuma kiasi cha pesa kwenda namba: <span className="font-black text-gray-900">0620 642 652</span> (Alexander Letema).</p>
            <p className="text-gray-600 font-medium">2. Baada ya kupokea SMS ya mtandao, bonyeza kitufe cha **"Hakiki Malipo"** hapa chini.</p>
          </div>

          {isVerifying ? (
            <div className="space-y-2">
              <div className="w-full bg-gray-100 h-2.5 rounded-full overflow-hidden border">
                <div className="bg-gradient-to-r from-blue-900 to-purple-600 h-full transition-all duration-700" style={{ width: `${verifyProgress}%` }}></div>
              </div>
              <p className="text-[11px] font-bold text-purple-700">Mfumo unahakiki muamala wa {customerInfo.paymentMethod}... {verifyProgress}%</p>
            </div>
          ) : (
            <button onClick={handleVerifyPayment} className="w-full bg-emerald-600 text-white text-xs font-black py-3.5 rounded-xl hover:bg-emerald-700 transition-all uppercase tracking-wider shadow-md">🔄 Hakiki Malipo Sasa</button>
          )}
        </div>
      )}

      {/* STEP 3: SUCCESS, AUTO PDF DOWNLOAD & WHATSAPP */}
      {step === 3 && (
        <div className="max-w-md mx-auto bg-white border border-gray-150 p-8 rounded-3xl shadow-xl text-center space-y-6">
          <div className="w-16 h-16 bg-emerald-50 border border-emerald-200 rounded-full flex items-center justify-center mx-auto text-emerald-600 text-2xl font-black animate-bounce">✓</div>
          
          <div>
            <h3 className="text-sm font-black text-gray-900 uppercase tracking-tight">Malipo Yamehakikiwa kwa 100%!</h3>
            <p className="text-xs text-gray-400 font-medium mt-1">Kila kitu kimekamilika kiotomatiki</p>
          </div>

          <div className="bg-slate-50 border rounded-2xl p-4 text-xs font-semibold text-gray-600 space-y-2 text-left">
            <p className="flex justify-between"><span>📄 Risiti ya Kielektroniki (PDF):</span> <span className="font-black text-emerald-600">Imepakuliwa Tayari</span></p>
            <p className="flex justify-between"><span>💬 Ujumbe wa WhatsApp:</span> <span className="font-black text-blue-900">Imetumwa kwa Utawala</span></p>
          </div>

          <button onClick={() => { setStep(1); setCustomerInfo({ name: '', phone: '', paymentMethod: 'M-Pesa' }); }} className="w-full bg-gray-900 text-white text-xs font-black py-3 rounded-xl hover:bg-gray-800 transition-all uppercase">↩ Rudi Kwenye Duka</button>
        </div>
      )}

    </div>
  );
}

