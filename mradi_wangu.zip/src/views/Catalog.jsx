import React, { useState, useEffect } from 'react';
import { supabase } from '../utils/supabaseClient';

export default function Catalog({ onAddToCart }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('All');

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('id', { ascending: true });

      if (error) throw error;
      setProducts(data || []);
    } catch (err) {
      console.error("Error fetching products:", err.message);
    } finally {
      setLoading(false);
    }
  };

  const categories = ['All', 'Internet', 'Document Services', 'Stationery', 'e-Gov', 'Digital Hub'];
  
  const filteredProducts = selectedCategory === 'All'
    ? products
    : products.filter(p => p.category.toLowerCase() === selectedCategory.toLowerCase());

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-900"></div>
        <span className="ml-3 font-bold text-gray-600">Inapakia Katalogi ya Kimkakati ya LSIC...</span>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      {/* BANNER YA JUU */}
      <div className="bg-white border border-gray-100 rounded-3xl p-6 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-black text-blue-900 uppercase tracking-tight">Katalogi Rasmi ya Huduma</h1>
          <p className="text-sm text-gray-500 font-semibold mt-1">
            Letema Stationery & Internet Café — Mbeya Business Hub
          </p>
        </div>
        
        {/* VITUFE VYA KUCHUJIA */}
        <div className="flex flex-wrap gap-2">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all border ${
                selectedCategory === cat
                  ? 'bg-blue-900 text-white border-blue-900 shadow-md'
                  : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
              }`}
            >
              {cat === 'All' ? 'Zote' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* GRID YA BIDHAA NA EBOOKS */}
      {filteredProducts.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-3xl border border-gray-100">
          <p className="text-sm text-gray-400 font-bold">Hakuna huduma zilizopatikana hapa.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 items-stretch">
          {filteredProducts.map(product => {
            const isEbook = product.category.toLowerCase() === 'digital hub';
            
            return (
              <div 
                key={product.id} 
                className="bg-white rounded-3xl border border-gray-150 p-4 transition-all duration-300 flex flex-col justify-between group h-full hover:shadow-2xl hover:-translate-y-2 transform cursor-pointer border-t-4 border-t-blue-950 hover:border-t-purple-600"
                style={{
                  boxShadow: '0 12px 24px -10px rgba(0,0,0,0.06)'
                }}
              >
                {/* SEHEMU YA JUU (IMAGE & DETAILS) */}
                <div className="space-y-3 flex-grow">
                  
                  {/* DISPLAY IMAGE / COVER ART YENYE VIVULI VYA 3D */}
                  <div className="w-full h-44 bg-gradient-to-b from-gray-50 to-white rounded-2xl overflow-hidden relative border border-gray-100 flex items-center justify-center">
                    <img 
                      src={product.image_url} 
                      alt={product.name}
                      className={`w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 ${
                        isEbook ? 'p-3 object-contain filter drop-shadow-2xl scale-105' : ''
                      }`}
                    />
                    
                    <span className={`absolute top-2 left-2 text-[9px] font-black tracking-wider uppercase px-2 py-0.5 rounded-md shadow-sm border ${
                      isEbook 
                        ? 'bg-purple-950 text-white border-purple-900' 
                        : 'bg-gray-900 text-white border-gray-800'
                    }`}>
                      {product.category}
                    </span>
                  </div>

                  <div className="space-y-1">
                    <h3 className="font-bold text-gray-900 text-sm group-hover:text-purple-700 transition-colors line-clamp-2 min-h-[40px] flex items-center leading-snug">
                      {isEbook ? `📚 ${product.name}` : product.name}
                    </h3>
                    <p className="text-xs text-gray-400 line-clamp-3 font-medium min-h-[48px] leading-relaxed">
                      {product.description}
                    </p>
                  </div>
                </div>
                
                {/* SEHEMU YA CHINI (BEI NA KITUFE CHA KUNUNUA) */}
                <div className="mt-4 pt-3 border-t border-gray-50 flex justify-between items-center bg-white">
                  <div>
                    <p className="text-[9px] text-gray-400 font-black uppercase tracking-wider">Gharama</p>
                    <p className="text-sm font-black text-blue-900">
                      {product.price.toLocaleString()} <span className="text-[9px] font-bold">TZS</span>
                    </p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onAddToCart(product);
                    }}
                    className={`text-white text-xs font-black px-4 py-2.5 rounded-xl transition-all shadow-md active:scale-95 transform ${
                      isEbook 
                        ? 'bg-purple-700 hover:bg-purple-800 shadow-purple-100' 
                        : 'bg-blue-900 hover:bg-amber-500 shadow-blue-100'
                    }`}
                  >
                    <span>{isEbook ? '📖 Nunua Kitabu' : '🛒 Chagua'}</span>
                  </button>
                </div>

              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

