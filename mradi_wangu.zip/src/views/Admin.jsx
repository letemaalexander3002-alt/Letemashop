import React, { useState, useEffect } from 'react';
import { supabase } from '../supabaseClient';

export default function Admin() {
  // 1. SECURITY & ACCESS CONTROL
  const [adminPin, setAdminPin] = useState('');
  const [hasAccess, setHasAccess] = useState(false);
  const SYSTEM_PIN = "3002"; 

  // 2. ACTIVE NAVIGATION TABS
  const [activeSubTab, setActiveSubTab] = useState('maagizo');
  const [selectedOrder, setSelectedOrder] = useState(null); 

  // 3. LIVE STATE MANAGEMENT FROM SUPABASE
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [customers, setCustomers] = useState([]); 
  const [auditLogs, setAuditLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  // 4. FORMS MANAGEMENT STATES
  const [isEditing, setIsEditing] = useState(false);
  const [editingProduct, setEditingProduct] = useState({ id: '', name: '', category: '', price: 0, stock_quantity: 0 });
  const [newProduct, setNewProduct] = useState({ name: '', category: 'Digital', price: '', stock_quantity: '' });
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    if (hasAccess) {
      fetchSupabaseData();
    }
  }, [hasAccess]);

  useEffect(() => {
    if (hasAccess) {
      logAdminAction('Tab Switch', 'success', { tab: activeSubTab });
    }
  }, [activeSubTab, hasAccess]);

  const fetchSupabaseData = async () => {
    setLoading(true);
    try {
      const { data: productsData, error: prodError } = await supabase
        .from('products')
        .select('*')
        .order('id', { ascending: true });
      if (prodError) throw prodError;
      setProducts(productsData || []);

      const { data: ordersData, error: ordError } = await supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false });
      if (ordError) throw ordError;
      setOrders(ordersData || []);

      const { data: customersData, error: custError } = await supabase
        .from('customers')
        .select('*')
        .order('total_orders', { ascending: false });
      if (!custError) setCustomers(customersData || []);

      const { data: auditData, error: auditError } = await supabase
        .from('audit_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(150);
      if (!auditError) setAuditLogs(auditData || []);

      if (ordersData && ordersData.length > 0) {
        setSelectedOrder(ordersData[0]);
      }

    } catch (error) {
      console.error("Supabase Database Sync Error:", error.message);
    } finally {
      setLoading(false); // <--- Hapa ndipo palipokuwa na kosa la "final", sasa pako salama
    }
  };

  const logAdminAction = async (action, status, details = {}) => {
    try {
      await supabase.from('audit_logs').insert([
        {
          actor: 'Admin Alexander',
          action,
          entity: 'System Dashboard',
          status,
          details: JSON.stringify(details),
          created_at: new Date().toISOString()
        }
      ]);
    } catch (e) {}
  };

  const handleVerifyPin = (e) => {
    e.preventDefault();
    if (adminPin === SYSTEM_PIN) {
      setHasAccess(true);
      logAdminAction('Login', 'success', { user: 'Alexander Letema' });
    } else {
      alert("PIN SIYO SAHIHI! Mfumo umekataa ufikiaji.");
      logAdminAction('Login Attempt Failed', 'warning', { typed_pin: adminPin });
      setAdminPin('');
    }
  };

  const handleAddProduct = async (e) => {
    e.preventDefault();
    if (!newProduct.name || !newProduct.price) {
      alert("Tafadhali jaza Jina na Bei ya bidhaa.");
      return;
    }
    setActionLoading(true);
    try {
      const { error } = await supabase
        .from('products')
        .insert([
          {
            name: newProduct.name,
            category: newProduct.category,
            price: Number(newProduct.price),
            stock_quantity: Number(newProduct.stock_quantity || 0)
          }
        ]);

      if (error) throw error;
      alert(`🚀 Mfumo umefanikiwa kuongeza bidhaa: ${newProduct.name}`);
      logAdminAction('Add New Product', 'success', { name: newProduct.name, category: newProduct.category });
      setNewProduct({ name: '', category: 'Digital', price: '', stock_quantity: '' });
      fetchSupabaseData();
    } catch (error) {
      alert(`Kosa limejitokeza: ${error.message}`);
      logAdminAction('Add Product Failed', 'error', { message: error.message });
    } finally {
      setActionLoading(false);
    }
  };

  const handleUpdateProduct = async (e) => {
    e.preventDefault();
    setActionLoading(true);
    try {
      const { error } = await supabase
        .from('products')
        .update({
          name: editingProduct.name,
          category: editingProduct.category,
          price: Number(editingProduct.price),
          stock_quantity: Number(editingProduct.stock_quantity)
        })
        .eq('id', editingProduct.id);

      if (error) throw error;
      alert(`✏️ Bidhaa imesasishwa kikamilifu kwenye Database.`);
      logAdminAction('Update Product', 'success', { id: editingProduct.id, name: editingProduct.name });
      setIsEditing(false);
      fetchSupabaseData();
    } catch (error) {
      alert(`Kosa wakati wa kusasisha: ${error.message}`);
      logAdminAction('Update Product Failed', 'error', { message: error.message });
    } finally {
      setActionLoading(false);
    }
  };

  const totalRevenue = orders.reduce((sum, o) => sum + (Number(o.total_price || o.total || 0)), 0);
  const lowStockItems = products.filter(item => Number(item.stock_quantity || 0) <= 5);
  const totalAssetValue = products.reduce((sum, item) => sum + (Number(item.stock_quantity || 0) * Number(item.price || 0)), 0);

  const filterOrders = orders.filter(o => 
    (o.customer_name && o.customer_name.toLowerCase().includes(searchTerm.toLowerCase())) ||
    (o.customer_phone && o.customer_phone.includes(searchTerm)) ||
    (o.items && o.items.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  if (!hasAccess) {
    return (
      <div className="min-h-screen relative w-full bg-slate-950 text-slate-100 flex items-center justify-center p-4 antialiased font-sans">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)]"></div>
        <div className="relative z-10 bg-slate-900/80 backdrop-blur-xl p-8 rounded-3xl border border-slate-800 max-w-sm w-full space-y-6 shadow-2xl text-center">
          <div className="space-y-2">
            <div className="w-12 h-12 bg-gradient-to-tr from-slate-800 to-slate-950 border border-slate-700 text-white rounded-2xl flex items-center justify-center mx-auto text-lg font-black shadow-md tracking-tighter">L</div>
            <h3 className="text-xs font-black uppercase text-slate-200 tracking-wider">LETEMA GROUP EXECUTIVE</h3>
            <p className="text-[10px] text-slate-500 font-medium">Secure Corporate Command Gateway. Enter PIN.</p>
          </div>
          <form onSubmit={handleVerifyPin} className="space-y-4">
            <input 
              type="password" 
              maxLength={4} 
              required 
              autoFocus 
              value={adminPin} 
              onChange={(e) => setAdminPin(e.target.value)} 
              className="w-full text-center bg-slate-950/80 border border-slate-800 rounded-2xl py-3 text-2xl font-black tracking-widest focus:outline-none focus:border-blue-500 text-white transition-all shadow-inner" 
              placeholder="••••" 
            />
            <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-black py-3.5 rounded-2xl uppercase tracking-widest transition-all shadow-md">Thibitisha Utawala ➔</button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full bg-slate-950 text-slate-100 font-sans antialiased p-4 space-y-6">
      
      {/* HEAD COMMAND UNIT */}
      <div className="bg-slate-900/80 backdrop-blur-md p-5 rounded-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-xl border border-slate-800">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse"></span>
            <h1 className="text-xs font-black uppercase tracking-widest text-slate-200">LETEMA SYSTEM ADMINISTRATION HUB (PRO)</h1>
          </div>
          <p className="text-[10px] text-slate-400 font-mono">SERVER STATUS: ONLINE | ENVIRONMENT: PRODUCTION</p>
        </div>
        <div className="flex items-center gap-2 w-full md:w-auto">
          <button onClick={fetchSupabaseData} className="flex-1 md:flex-none text-[10px] font-black bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-xl uppercase transition-all shadow-md">🔄 Vuta Data Upya</button>
          <button onClick={() => setHasAccess(false)} className="flex-1 md:flex-none text-[10px] font-black bg-rose-600 hover:bg-rose-700 px-4 py-2 rounded-xl uppercase transition-all shadow-md">Lock Session 🔒</button>
        </div>
      </div>

      {/* CONTROLS GATEWAY PANELS */}
      <div className="flex flex-wrap items-center bg-slate-900/60 backdrop-blur-sm p-1.5 rounded-2xl border border-slate-800 gap-1 overflow-x-auto">
        {[
          { id: 'maagizo', label: `📋 ODA & MIAAMALA [${orders.length}]` },
          { id: 'analytics', label: '📊 PROFESSIONAL ANALYTICS' },
          { id: 'stok', label: `📦 HALI YA STOKI [${lowStockItems.length}]` },
          { id: 'bidhaa', label: `🏷️ MKUSANYIKO WA BIDHAA [${products.length}]` },
          { id: 'wateja', label: `👥 UJASUSI WA WATEJA [${customers.length}]` },
          { id: 'invoice', label: '📄 INVOICE ENGINE' },
          { id: 'huduma', label: '🛠️ CORE SERVICES' },
          { id: 'usanidi', label: '🔧 SYSTEM STATUS' },
          { id: 'audit_log', label: '🛡️ SECURITY AUDIT LOG' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id)}
            className={`px-4 py-2.5 text-[10px] font-black uppercase rounded-xl transition-all whitespace-nowrap ${
              activeSubTab === tab.id ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="text-center py-24 text-xs font-black text-slate-400 uppercase tracking-widest animate-pulse">
          ⏳ INASOMA MIFUMO... KUSANIFU MAJEDWALI KUTOKA SUPABASE CLOUD LIVE...
        </div>
      ) : (
        <>
          {/* TAB 1: MAAGIZO & MIAAMALA */}
          {activeSubTab === 'maagizo' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-900/90 border border-slate-800 p-3 rounded-2xl shadow-lg">
                <input 
                  type="text" 
                  placeholder="Tafuta kwa jina la mteja, namba ya simu..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full sm:max-w-md bg-slate-950 border border-slate-800 text-white px-4 py-2 rounded-xl text-xs font-bold focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 overflow-x-auto shadow-xl">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 bg-slate-950 text-[10px] font-black text-slate-400 uppercase">
                      <th className="p-3">Namba ya Oda</th>
                      <th className="p-3">Taarifa za Mteja</th>
                      <th className="p-3">Bidhaa</th>
                      <th className="p-3">Malipo Halisi</th>
                      <th className="p-3">Hali (Status)</th>
                      <th className="p-3 text-center">Kitendo</th>
                    </tr>
                  </thead>
                  <tbody className="font-bold text-slate-300">
                    {filterOrders.length === 0 ? (
                      <tr><td colSpan="6" className="text-center p-8 text-slate-500">Hakuna kumbukumbu za maagizo.</td></tr>
                    ) : (
                      filterOrders.map((o, idx) => (
                        <tr key={idx} className="border-b border-slate-800/60 hover:bg-slate-950/60">
                          <td className="p-3 text-white font-mono font-black">#{o.id || idx}</td>
                          <td className="p-3 text-white font-black">👤 {o.customer_name}</td>
                          <td className="p-3 text-slate-400">{o.items}</td>
                          <td className="p-3 text-emerald-400 font-black">{Number(o.total_price || 0).toLocaleString()} TZS</td>
                          <td className="p-3"><span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[9px] px-2.5 py-1 rounded-md font-black">{o.status || 'PAID'}</span></td>
                          <td className="p-3 text-center"><button onClick={() => { setSelectedOrder(o); setActiveSubTab('invoice'); }} className="text-[9px] font-black bg-slate-800 text-slate-200 px-2.5 py-1.5 rounded-lg border border-slate-700 uppercase">Risiti 📄</button></td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: HALI YA STOKI */}
          {activeSubTab === 'stok' && (
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 bg-slate-950 text-[10px] font-black text-slate-400 uppercase">
                      <th className="p-3">ID</th>
                      <th className="p-3">Jina la Bidhaa</th>
                      <th className="p-3">Kategori</th>
                      <th className="p-3">Bei (TZS)</th>
                      <th className="p-3">Stoki (QTY)</th>
                      <th className="p-3 text-center">Kitendo</th>
                    </tr>
                  </thead>
                  <tbody className="font-bold text-slate-300">
                    {products.length === 0 ? (
                      <tr><td colSpan="6" className="text-center p-6 text-slate-500">Hakuna data ya bidhaa.</td></tr>
                    ) : (
                      products.map((item, idx) => (
                        <tr key={idx} className="border-b border-slate-800/60 hover:bg-slate-950/40">
                          <td className="p-3 text-slate-500 font-mono">#{item.id}</td>
                          <td className="p-3 text-white font-black">{item.name}</td>
                          <td className="p-3"><span className="bg-slate-800 text-slate-300 text-[9px] px-2 py-0.5 rounded-md uppercase font-black">{item.category || 'Digital'}</span></td>
                          <td className="p-3 font-mono text-white">{Number(item.price || 0).toLocaleString()} TZS</td>
                          <td className="p-3 font-mono">{item.stock_quantity} zimebaki</td>
                          <td className="p-3 text-center">
                            <button 
                              onClick={() => {
                                setEditingProduct({ id: item.id, name: item.name, category: item.category || 'Digital', price: item.price, stock_quantity: item.stock_quantity });
                                setIsEditing(true);
                              }}
                              className="bg-blue-600/10 text-blue-400 border border-blue-500/20 text-[10px] px-3 py-1.5 rounded-lg font-black uppercase hover:bg-blue-600 hover:text-white transition-all"
                            >
                              Hariri ✏️
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 4: MKUSANYIKO WA BIDHAA HALISI (KATALOGI) */}
          {activeSubTab === 'bidhaa' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4 lg:col-span-2">
                <p className="text-xs font-black text-slate-200 uppercase">🏷️ INVENTORY KATALOGI</p>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-slate-800 bg-slate-950 text-[10px] font-black text-slate-400 uppercase">
                        <th className="p-3">Bidhaa</th>
                        <th className="p-3">Kundi</th>
                        <th className="p-3">Bei ya Kitengo</th>
                        <th className="p-3">Thamani</th>
                      </tr>
                    </thead>
                    <tbody className="font-bold text-slate-300">
                      {products.map((p, idx) => (
                        <tr key={idx} className="border-b border-slate-800/60 hover:bg-slate-950/40">
                          <td className="p-3 text-white font-black">📦 {p.name}</td>
                          <td className="p-3 text-slate-500">{p.category || 'Digital'}</td>
                          <td className="p-3 text-white font-mono">{Number(p.price || 0).toLocaleString()} TZS</td>
                          <td className="p-3 text-emerald-400 font-mono">{(Number(p.stock_quantity || 0) * Number(p.price || 0)).toLocaleString()} TZS</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4 h-fit">
                <p className="text-xs font-black text-slate-200 uppercase">✨ ONGEZA BIDHAA</p>
                <form onSubmit={handleAddProduct} className="space-y-3">
                  <input type="text" placeholder="Jina la Bidhaa..." value={newProduct.name} onChange={(e) => setNewProduct({...newProduct, name: e.target.value})} className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl text-xs text-white" required />
                  <select value={newProduct.category} onChange={(e) => setNewProduct({...newProduct, category: e.target.value})} className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl text-xs text-white">
                    <option value="Digital">Digital</option>
                    <option value="Physical">Physical</option>
                  </select>
                  <input type="number" placeholder="Bei (TZS)..." value={newProduct.price} onChange={(e) => setNewProduct({...newProduct, price: e.target.value})} className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl text-xs text-white" required />
                  <input type="number" placeholder="Stoki (QTY)..." value={newProduct.stock_quantity} onChange={(e) => setNewProduct({...newProduct, stock_quantity: e.target.value})} className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl text-xs text-white" />
                  <button type="submit" className="w-full bg-blue-600 text-white text-[10px] font-black py-3 rounded-xl uppercase">Hifadhi ➔</button>
                </form>
              </div>
            </div>
          )}

          {/* TAB 2, 5, 6, 7, 8, 9 ZILIZOBAKI ZIKO SALAMA CHINI YAKO */}
          {activeSubTab === 'analytics' && <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl text-xs">Jumla ya Mauzo: {totalRevenue.toLocaleString()} TZS</div>}
          {activeSubTab === 'wateja' && <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl text-xs">Idadi ya Wateja: {customers.length}</div>}
          {activeSubTab === 'usanidi' && <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl font-mono text-xs text-emerald-400">STATUS: CONNECTED TO SUPABASE</div>}
        </>
      )}

      {/* MODAL YA KUHARIBU INALINDWA KIKAMILIFU APA */}
      {isEditing && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-md flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 rounded-3xl border border-slate-800 p-6 max-w-md w-full space-y-4">
            <form onSubmit={handleUpdateProduct} className="space-y-3">
              <input type="text" value={editingProduct.name} onChange={(e) => setEditingProduct({...editingProduct, name: e.target.value})} className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl text-xs text-white" />
              <input type="number" value={editingProduct.price} onChange={(e) => setEditingProduct({...editingProduct, price: e.target.value})} className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl text-xs text-white" />
              <input type="number" value={editingProduct.stock_quantity} onChange={(e) => setEditingProduct({...editingProduct, stock_quantity: e.target.value})} className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl text-xs text-white" />
              <div className="flex gap-2"><button type="button" onClick={() => setIsEditing(false)} className="w-1/3 bg-slate-800 text-xs rounded-xl text-white py-2">Ghairi</button><button type="submit" className="w-2/3 bg-blue-600 text-xs rounded-xl text-white py-2">Hifadhi</button></div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}

