import React, { useState, useEffect } from 'react';
import { supabase } from './supabaseClient';

export default function App() {
  // --- STATE ZA MFUMO GENERAL ---
  const [currentView, setCurrentView] = useState('katalogi'); // 'katalogi', 'checkout', 'admin'
  const [huduma, setHuduma] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('Zote');

  // --- STATE ZA CHECKOUT NA KIKAPU ---
  const [cart, setCart] = useState([]);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [checkoutLoading, setCheckoutLoading] = useState(false);

  // --- STATE ZA ADMIN DASHBOARD ---
  const [adminPin, setAdminPin] = useState('');
  const [hasAdminAccess, setHasAdminAccess] = useState(false);
  const [activeAdminTab, setActiveAdminTab] = useState('maagizo');
  const [orders, setOrders] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [newProduct, setNewProduct] = useState({ name: '', category: 'Internet', price: '', stock_quantity: '' });

  const SYSTEM_PIN = "3002";

  // VUTA DATA KUTOKA SUPABASE
  const fetchAllData = async () => {
    try {
      setLoading(true);
      // 1. Vuta Bidhaa/Huduma
      const { data: prodData, error: prodErr } = await supabase
        .from('products')
        .select('*')
        .order('id', { ascending: true });
      if (prodErr) throw prodErr;
      
      const dataWithImages = (prodData || []).map(item => ({
        ...item,
        img: item.image_url || (
          item.category === 'Internet' 
            ? "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=500&q=80"
            : "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=500&q=80"
        )
      }));
      setHuduma(dataWithImages);

      // 2. Vuta Oda za Admin
      const { data: ordData } = await supabase.from('orders').select('*').order('id', { ascending: false });
      setOrders(ordData || []);

      // 3. Vuta Wateja
      const { data: custData } = await supabase.from('customers').select('*');
      setCustomers(custData || []);

    } catch (err) {
      console.error("Supabase Dynamic Sync Error:", err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  // --- VITENDO VYA KIKAPU & CHECKOUT ---
  const addToCart = (item) => {
    setCart([...cart, item]);
    alert(`🛒 ${item.name} imeongezwa kwenye kikapu!`);
  };

  const handleCheckoutSubmit = async (e) => {
    e.preventDefault();
    if (cart.length === 0) return alert("Kikapu chako kiko tupu!");
    setCheckoutLoading(true);

    const itemsSummary = cart.map(i => i.name).join(', ');
    const totalPrice = cart.reduce((sum, i) => sum + Number(i.price || 0), 0);

    try {
      // 1. Ingiza Oda
      const { error: orderErr } = await supabase.from('orders').insert([
        { customer_name: customerName, customer_phone: customerPhone, items: itemsSummary, total_price: totalPrice, status: 'PAID' }
      ]);
      if (orderErr) throw orderErr;

      // 2. Ingiza/Sasisha Mteja
      await supabase.from('customers').insert([
        { customer_name: customerName, customer_phone: customerPhone, total_orders: 1, total_spent: totalPrice }
      ]).select();

      alert("🚀 MALIPO YAMEKUBALIWA! Oda yako imesajiliwa kikamilifu.");
      setCart([]);
      setCustomerName('');
      setCustomerPhone('');
      setCurrentView('katalogi');
      fetchAllData();
    } catch (err) {
      alert("Hitilafu kwenye malipo: " + err.message);
    } finally {
      setCheckoutLoading(false);
    }
  };

  // --- VERIFY ADMIN PIN ---
  const handleVerifyPin = (e) => {
    e.preventDefault();
    if (adminPin === SYSTEM_PIN) {
      setHasAdminAccess(true);
      setCurrentView('admin');
    } else {
      alert("PIN SIYO SAHIHI!");
      setAdminPin('');
    }
  };

  const handleAddProduct = async (e) => {
    e.preventDefault();
    try {
      const { error } = await supabase.from('products').insert([
        { name: newProduct.name, category: newProduct.category, price: Number(newProduct.price), stock_quantity: Number(newProduct.stock_quantity || 0) }
      ]);
      if (error) throw error;
      alert("Bidhaa imeongezwa live kule Supabase!");
      setNewProduct({ name: '', category: 'Internet', price: '', stock_quantity: '' });
      fetchAllData();
    } catch (err) { alert(err.message); }
  };

  const filteredHuduma = activeTab === 'Zote' ? huduma : huduma.filter(h => h.category === activeTab);
  const totalCartPrice = cart.reduce((sum, i) => sum + Number(i.price || 0), 0);

  // ==================== VIEW 1: KATALOGI YA ASILI YA WATEJA ====================
  if (currentView === 'katalogi') {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-800 font-sans">
        <header className="bg-white border-b border-slate-200 sticky top-0 z-50 px-4 py-4 shadow-sm">
          <div className="max-w-4xl mx-auto flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <span className="text-xl font-black text-blue-900 tracking-tight">LETEMA</span>
              <span className="bg-amber-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-md uppercase">GROUP</span>
            </div>
            <div className="flex items-center space-x-4 text-xs font-bold text-slate-600">
              <span className="text-amber-600 font-black">Katalogi</span>
              <span onClick={() => setCurrentView('checkout')} className="bg-amber-100 text-amber-800 px-3 py-1.5 rounded-lg flex items-center gap-1 cursor-pointer hover:bg-amber-200 transition-all">
                🛒 Kikapu ({cart.length})
              </span>
              <button onClick={() => setCurrentView('admin_login')} className="bg-blue-950 text-white px-4 py-1.5 rounded-lg font-bold text-[10px] uppercase tracking-wider">🔐 Admin Portal</button>
            </div>
          </div>
        </header>

        <main className="max-w-4xl mx-auto px-4 py-6 space-y-6">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
            <div className="space-y-1">
              <h1 className="text-xl font-black text-blue-900 uppercase tracking-tight">KATALOGI RASMI YA HUDUMA</h1>
              <p className="text-xs text-slate-500 font-medium">Letema Stationery & Internet Café — Mbeya Business Hub</p>
            </div>
            <div className="flex flex-wrap gap-2 pt-2">
              {['Zote', 'Internet', 'Document Services', 'Stationery', 'e-Gov', 'Digital Hub'].map((tab) => (
                <button key={tab} onClick={() => setActiveTab(tab)} className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all border ${activeTab === tab ? 'bg-blue-900 text-white border-blue-900' : 'bg-white text-slate-600 border-slate-200'}`}>{tab}</button>
              ))}
            </div>
          </div>

          {loading ? (
            <div className="text-center py-12 text-xs font-bold text-slate-400 animate-pulse uppercase">⏳ INAVUTA DATA KUTOKA SUPABASE...</div>
          ) : (
            <div className="space-y-4">
              {filteredHuduma.map((item) => (
                <div key={item.id} className="bg-white border-2 border-slate-800 rounded-3xl overflow-hidden shadow-sm flex flex-col">
                  <div className="h-48 w-full bg-slate-200 relative"><img src={item.img} alt={item.name} className="w-full h-full object-cover" /><span className="absolute top-3 left-3 bg-black text-white text-[9px] font-black uppercase px-2 py-0.5 rounded-md">{item.category || 'General'}</span></div>
                  <div className="p-5 space-y-4 flex-1 flex flex-col justify-between">
                    <div className="space-y-2">
                      <h3 className="text-sm font-black text-slate-900 leading-tight">{item.name}</h3>
                      <p className="text-xs text-slate-500 font-medium">{item.description || 'Huduma bora na ya haraka kutoka Letema Business Hub.'}</p>
                    </div>
                    <div className="pt-4 border-t border-slate-100 flex justify-between items-center">
                      <div><span className="text-[9px] text-slate-400 font-bold block uppercase">GHARAMA</span><span className="text-sm font-black text-blue-900">{Number(item.price || 0).toLocaleString()} TZS</span></div>
                      <button onClick={() => addToCart(item)} className="bg-blue-900 hover:bg-blue-950 text-white text-xs font-black px-5 py-2.5 rounded-xl uppercase tracking-wider">🛒 Chagua</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </main>
      </div>
    );
  }

  // ==================== VIEW 2: CHECKOUT YA KITAALAMU ====================
  if (currentView === 'checkout') {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-800 p-4">
        <div className="max-w-md mx-auto bg-white border-2 border-slate-900 rounded-3xl p-6 shadow-2xl space-y-6">
          <div className="flex justify-between items-center border-b pb-4">
            <h2 className="text-sm font-black text-blue-900 uppercase">🛒 CHECKOUT YA KITAALAMU</h2>
            <button onClick={() => setCurrentView('katalogi')} className="text-xs font-bold text-rose-600">➔ Rudi Nyuma</button>
          </div>

          <div className="space-y-2">
            <p className="text-[10px] font-black text-slate-400 uppercase">Muhtasari wa Kikapu</p>
            {cart.map((i, idx) => (
              <div key={idx} className="flex justify-between items-center bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-xs font-bold">
                <span>{i.name}</span>
                <span className="text-blue-900">{Number(i.price).toLocaleString()} TZS</span>
              </div>
            ))}
            <div className="border-t pt-3 flex justify-between text-sm font-black text-slate-900">
              <span>JUMLA KUU:</span>
              <span className="text-emerald-600">{totalCartPrice.toLocaleString()} TZS</span>
            </div>
          </div>

          <form onSubmit={handleCheckoutSubmit} className="space-y-4">
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-slate-500">Jina Kamili la Mteja</label>
              <input type="text" required value={customerName} onChange={(e) => setCustomerName(e.target.value)} className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-blue-900" placeholder="Mfano: Hellen Letema" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-slate-500">Namba ya Simu</label>
              <input type="text" required value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-blue-900" placeholder="Mfano: 0712345678" />
            </div>
            <button type="submit" disabled={checkoutLoading} className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black py-3 rounded-xl uppercase tracking-widest transition-all">
              {checkoutLoading ? "INASAKINISHA MALIPO..." : "KAMILISHA AGIZO (LIVE) ➔"}
            </button>
          </form>
        </div>
      </div>
    );
  }

  // ==================== VIEW 3: ADMIN LOGIN COMMAND PORTAL ====================
  if (currentView === 'admin_login') {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
        <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 max-w-sm w-full space-y-6 text-center shadow-2xl">
          <h3 className="text-xs font-black uppercase text-slate-200 tracking-wider">LETEMA GROUP EXECUTIVE</h3>
          <p className="text-[10px] text-slate-500">Weka PIN ya Utawala kuingia kwenye Mfumo wa Giza.</p>
          <form onSubmit={handleVerifyPin} className="space-y-4">
            <input type="password" maxLength={4} required autoFocus value={adminPin} onChange={(e) => setAdminPin(e.target.value)} className="w-full text-center bg-slate-950 border border-slate-800 rounded-2xl py-3 text-2xl font-black text-white focus:outline-none focus:border-blue-500" placeholder="••••" />
            <div className="flex gap-2">
              <button type="button" onClick={() => setCurrentView('katalogi')} className="w-1/3 bg-slate-800 text-white text-[10px] font-black py-3 rounded-2xl uppercase">Ghairi</button>
              <button type="submit" className="w-2/3 bg-blue-600 text-white text-[10px] font-black py-3 rounded-2xl uppercase">Ingia ➔</button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  // ==================== VIEW 4: ADMIN INDUSTRIAL DASHBOARD (ASILI) ====================
  if (currentView === 'admin' && hasAdminAccess) {
    return (
      <div className="min-h-screen w-full bg-slate-950 text-slate-100 p-4 space-y-6 font-sans antialiased">
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl flex justify-between items-center shadow-xl">
          <div>
            <h1 className="text-xs font-black uppercase tracking-widest text-slate-200">LETEMA SYSTEM ADMINISTRATION HUB (PRO)</h1>
            <p className="text-[9px] text-slate-500 font-mono">SUPABASE LIVE DATABASE SYNC ACTIVE</p>
          </div>
          <div className="flex gap-2">
            <button onClick={fetchAllData} className="text-[10px] font-black bg-blue-600 px-4 py-2 rounded-xl uppercase">🔄 Vuta Data</button>
            <button onClick={() => { setHasAdminAccess(false); setCurrentView('katalogi'); }} className="text-[10px] font-black bg-rose-600 px-4 py-2 rounded-xl uppercase">Toka Portal 🔒</button>
          </div>
        </div>

        {/* TABS CONTROLS */}
        <div className="flex flex-wrap bg-slate-900/60 p-1.5 rounded-2xl border border-slate-800 gap-1 overflow-x-auto">
          {[{ id: 'maagizo', label: `📋 ODA & MIAAMALA [${orders.length}]` }, { id: 'bidhaa', label: `🏷️ MKUSANYIKO WA BIDHAA [${huduma.length}]` }, { id: 'wateja', label: `👥 UJASUSI WA WATEJA [${customers.length}]` }].map(t => (
            <button key={t.id} onClick={() => setActiveAdminTab(t.id)} className={`px-4 py-2 text-[10px] font-black uppercase rounded-xl ${activeAdminTab === t.id ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800'}`}>{t.label}</button>
          ))}
        </div>

        {/* TAB CONTENTS */}
        {activeAdminTab === 'maagizo' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950 text-[10px] font-black text-slate-400 uppercase"><th className="p-3">Oda ID</th><th className="p-3">Mteja</th><th className="p-3">Huduma/Bidhaa</th><th className="p-3">Malipo (TZS)</th><th className="p-3">Hali</th></tr>
              </thead>
              <tbody className="font-bold text-slate-300">
                {orders.map((o, idx) => (
                  <tr key={idx} className="border-b border-slate-800/60 hover:bg-slate-950/60">
                    <td className="p-3 font-mono text-white">#{o.id}</td>
                    <td className="p-3 text-white">👤 {o.customer_name} ({o.customer_phone})</td>
                    <td className="p-3 text-slate-400">{o.items}</td>
                    <td className="p-3 text-emerald-400 font-black">{Number(o.total_price || 0).toLocaleString()} TZS</td>
                    <td className="p-3"><span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[9px] px-2 py-0.5 rounded-md font-black">{o.status || 'PAID'}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeAdminTab === 'bidhaa' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 lg:col-span-2 overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950 text-[10px] font-black text-slate-400 uppercase"><th className="p-3">Jina la Huduma</th><th className="p-3">Kundi</th><th className="p-3">Bei</th><th className="p-3">Stoki (QTY)</th></tr>
                </thead>
                <tbody className="font-bold text-slate-300">
                  {huduma.map((p, idx) => (
                    <tr key={idx} className="border-b border-slate-800/60 hover:bg-slate-950/40">
                      <td className="p-3 text-white font-black">📦 {p.name}</td>
                      <td className="p-3 text-slate-500">{p.category || 'Internet'}</td>
                      <td className="p-3 text-white font-mono">{Number(p.price || 0).toLocaleString()} TZS</td>
                      <td className="p-3 font-mono text-slate-400">{p.stock_quantity || 0} left</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 h-fit space-y-4">
              <p className="text-xs font-black text-slate-200 uppercase">✨ ONGEZA LIVE SUPABASE</p>
              <form onSubmit={handleAddProduct} className="space-y-3">
                <input type="text" placeholder="Jina la Bidhaa..." value={newProduct.name} onChange={(e) => setNewProduct({...newProduct, name: e.target.value})} className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl text-xs text-white" required />
                <select value={newProduct.category} onChange={(e) => setNewProduct({...newProduct, category: e.target.value})} className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl text-xs text-white">
                  <option value="Internet">Internet</option>
                  <option value="Document Services">Document Services</option>
                  <option value="Stationery">Stationery</option>
                </select>
                <input type="number" placeholder="Bei (TZS)..." value={newProduct.price} onChange={(e) => setNewProduct({...newProduct, price: e.target.value})} className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl text-xs text-white" required />
                <input type="number" placeholder="Stoki (QTY)..." value={newProduct.stock_quantity} onChange={(e) => setNewProduct({...newProduct, stock_quantity: e.target.value})} className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl text-xs text-white" />
                <button type="submit" className="w-full bg-blue-600 text-white text-[10px] font-black py-3 rounded-xl uppercase">Hifadhi ➔</button>
              </form>
            </div>
          </div>
        )}

        {activeAdminTab === 'wateja' && (
          <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl text-xs">
            <p className="font-bold uppercase text-slate-400 mb-2">Orodha ya Wateja Waliosajiliwa kwenye Mfumo</p>
            {customers.map((c, idx) => (
              <div key={idx} className="border-b border-slate-800 py-2 flex justify-between text-white font-bold">
                <span>👤 {c.customer_name} ({c.customer_phone})</span>
                <span className="text-emerald-400">Jumla ya Manunuzi: {Number(c.total_spent || 0).toLocaleString()} TZS</span>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  return null;
}

